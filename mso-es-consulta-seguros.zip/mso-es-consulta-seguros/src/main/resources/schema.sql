CREATE TABLE PUBLIC.SEGUROS(ID BIGINT PRIMARY KEY,
                        NOMBRE VARCHAR(30),
                        DESCRIPCION VARCHAR(250),
                        PRIMA_TOTAL NUMERIC(6,2),
                        EDAD_MIN INT,
                        EDAD_MAX INT,
                        ID_GENERO INT);

CREATE TABLE PUBLIC.BENEFICIOS(ID BIGINT PRIMARY KEY,
                        DESCRIPCION VARCHAR(150),
                        SEGURO_ID BIGINT,
                        foreign key (SEGURO_ID) references seguros(ID));



CREATE TABLE PUBLIC.REQUISITOS(ID BIGINT PRIMARY KEY,
                        DESCRIPCION VARCHAR(150),
                        SEGURO_ID BIGINT,
                        foreign key (SEGURO_ID) references seguros(ID));

