INSERT INTO seguros ("ID","NOMBRE","DESCRIPCION","PRIMA_TOTAL", "EDAD_MIN", "EDAD_MAX", "ID_GENERO")VALUES(1,'VIDA','Protección económica para tu familia en caso de fallecimiento natural o accidental.',700.00, 18, 75, 0);
INSERT INTO seguros ("ID","NOMBRE","DESCRIPCION","PRIMA_TOTAL", "EDAD_MIN", "EDAD_MAX", "ID_GENERO")VALUES(2,'INFARTO','Protección económica de $50,000 por la primera ocurrencia de infarto al miocardio.',300.00, 15, 64, 0);
INSERT INTO seguros ("ID","NOMBRE","DESCRIPCION","PRIMA_TOTAL", "EDAD_MIN", "EDAD_MAX", "ID_GENERO")VALUES(3,'MUJER','Protección económica de $50,000 por el primer diagnóstico de cáncer de mama o cervicouterino.',300.00,15,64,2);

INSERT INTO beneficios ("ID","DESCRIPCION","SEGURO_ID")VALUES(1,'Beneficio económico para tu familia, que se incrementará en caso de fallecimiento accidental.',1);
INSERT INTO beneficios ("ID","DESCRIPCION","SEGURO_ID")VALUES(2,'Servicio funerario sin costo adicional.',1);

INSERT INTO beneficios ("ID","DESCRIPCION","SEGURO_ID")VALUES(3,'Envío de ambulancia.',2);
INSERT INTO beneficios ("ID","DESCRIPCION","SEGURO_ID")VALUES(4,'Consultas médicas telefónicas ilimitadas.',2);
INSERT INTO beneficios ("ID","DESCRIPCION","SEGURO_ID")VALUES(5,'No se requiere presentar exámenes médicos.',2);

INSERT INTO beneficios ("ID","DESCRIPCION","SEGURO_ID")VALUES(6,'20 consultas psicológicas a domicilio, que aplican siempre y cuando se haya diagnosticado el cáncer.',3);
INSERT INTO beneficios ("ID","DESCRIPCION","SEGURO_ID")VALUES(7,'Consultas psicológicas por teléfono ilimitadas.',3);
INSERT INTO beneficios ("ID","DESCRIPCION","SEGURO_ID")VALUES(8,'No se requiere presentar exámenes médicos.',3);

INSERT INTO requisitos ("ID","DESCRIPCION","SEGURO_ID")VALUES(1,'Tener entre 18 y 75 años',1);
INSERT INTO requisitos ("ID","DESCRIPCION","SEGURO_ID")VALUES(2,'Tener entre 15 y 64 años',2);
INSERT INTO requisitos ("ID","DESCRIPCION","SEGURO_ID")VALUES(3,'Tener entre 15 y 64 años',3);
INSERT INTO requisitos ("ID","DESCRIPCION","SEGURO_ID")VALUES(4,'Ser mujer',3);
