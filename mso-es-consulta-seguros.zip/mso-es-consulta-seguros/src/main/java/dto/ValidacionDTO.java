package dto;

import java.io.Serializable;

public class ValidacionDTO implements Serializable {
    private Long idSeguro;
    private Cliente cliente;

    public Long getIdSeguro() {
        return idSeguro;
    }

    public void setIdSeguro(Long idSeguro) {
        this.idSeguro = idSeguro;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
