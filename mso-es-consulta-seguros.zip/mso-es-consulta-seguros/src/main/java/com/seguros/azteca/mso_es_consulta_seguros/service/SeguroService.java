package com.seguros.azteca.mso_es_consulta_seguros.service;

import com.seguros.azteca.mso_es_consulta_seguros.entity.Seguro;

import java.util.List;

public interface SeguroService {

    List<Seguro> findAll();
    Seguro findById(Long id);
}
