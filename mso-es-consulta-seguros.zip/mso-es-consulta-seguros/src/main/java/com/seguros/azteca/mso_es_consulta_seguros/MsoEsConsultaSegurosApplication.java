package com.seguros.azteca.mso_es_consulta_seguros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class MsoEsConsultaSegurosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsoEsConsultaSegurosApplication.class, args);
	}

}
