package com.seguros.azteca.mso_es_consulta_seguros.controller;

import com.seguros.azteca.mso_es_consulta_seguros.entity.Seguro;
import com.seguros.azteca.mso_es_consulta_seguros.service.SeguroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/v1")
public class SeguroController {

    @Autowired
    private SeguroService seguroService;

    @GetMapping
    public List<Seguro> getAll() {
        return seguroService.findAll();
    }

    @GetMapping("/{id}")
    public Seguro getAll(@PathVariable Long id) {
        return seguroService.findById(id);
    }
}
