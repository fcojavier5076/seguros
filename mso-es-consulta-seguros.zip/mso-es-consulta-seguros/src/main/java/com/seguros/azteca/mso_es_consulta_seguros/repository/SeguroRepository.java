package com.seguros.azteca.mso_es_consulta_seguros.repository;

import com.seguros.azteca.mso_es_consulta_seguros.entity.Seguro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SeguroRepository extends JpaRepository<Seguro, Long> {
    Seguro findById(long id);
}
