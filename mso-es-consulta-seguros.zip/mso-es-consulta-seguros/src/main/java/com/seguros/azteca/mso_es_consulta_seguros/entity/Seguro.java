package com.seguros.azteca.mso_es_consulta_seguros.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity (name = "seguros")
public class Seguro {
    @Id
    private Long id;

    @Column
    private String nombre;

    @Column
    private String descripcion;

    @Column
    private BigDecimal primaTotal;

    @Column
    private Integer edadMin;

    @Column
    private Integer edadMax;

    @Column
    private Integer idGenero;


    @JsonManagedReference
    @OneToMany(mappedBy = "seguro", fetch = FetchType.EAGER)
    private List<Beneficio> beneficios = new ArrayList<>();

    @JsonManagedReference
    @OneToMany(mappedBy = "seguro", fetch = FetchType.EAGER)
    private List<Requisito> requisitos = new ArrayList<>();

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public BigDecimal getPrimaTotal() {
        return primaTotal;
    }

    public void setPrimaTotal(BigDecimal primaTotal) {
        this.primaTotal = primaTotal;
    }

    public List<Beneficio> getBeneficios() {
        return beneficios;
    }

    public void setBeneficios(List<Beneficio> beneficios) {
        this.beneficios = beneficios;
    }

    public List<Requisito> getRequisitos() {
        return requisitos;
    }

    public void setRequisitos(List<Requisito> requisitos) {
        this.requisitos = requisitos;
    }

    public Integer getEdadMin() {
        return edadMin;
    }

    public void setEdadMin(Integer edadMin) {
        this.edadMin = edadMin;
    }

    public Integer getEdadMax() {
        return edadMax;
    }

    public void setEdadMax(Integer edadMax) {
        this.edadMax = edadMax;
    }

    public Integer getIdGenero() {
        return idGenero;
    }

    public void setIdGenero(Integer idGenero) {
        this.idGenero = idGenero;
    }
}
