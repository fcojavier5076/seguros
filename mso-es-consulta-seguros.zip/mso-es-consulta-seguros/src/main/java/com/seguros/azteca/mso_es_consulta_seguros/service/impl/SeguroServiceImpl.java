package com.seguros.azteca.mso_es_consulta_seguros.service.impl;

import com.seguros.azteca.mso_es_consulta_seguros.entity.Seguro;
import com.seguros.azteca.mso_es_consulta_seguros.repository.SeguroRepository;
import com.seguros.azteca.mso_es_consulta_seguros.service.SeguroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeguroServiceImpl implements SeguroService {

    @Autowired
    private SeguroRepository seguroRepository;

    @Override
    public List<Seguro> findAll() {
        return seguroRepository.findAll();
    }

    @Override
    public Seguro findById(Long id) {
        return seguroRepository.findById(id).orElse(null);
    }
}
