package com.seguros.azteca.mso_es_consulta_seguros.client;

import dto.ResponseDto;
import dto.ValidacionDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "validacionesClient", url = "http://localhost:8080")
public interface ValidacionesClient {

    @PostMapping
     ResponseDto validarSeguro(@RequestBody ValidacionDTO validacionDTO);
}
