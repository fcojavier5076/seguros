package com.seguros.azteca.mso_es_consulta_seguros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsoEsConsultaSegurosApplicationTests {

	@Test
	void contextLoads() {
	}

}
